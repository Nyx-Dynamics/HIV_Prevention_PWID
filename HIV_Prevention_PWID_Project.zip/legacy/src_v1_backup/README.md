# Publication Source Code

This directory contains the source code specifically optimized and generalized for scientific publication and journal submission.

## Cross-Reference to Primary SRC
These scripts are functionally identical to those in the root `SRC/` directory but are maintained here within the `Publication_Materials` framework to ensure that the reproducibility suite (via the root `Makefile` and `Publication_Materials/Makefile`) has a stable and isolated environment for generating submission-ready figures and data.

## Usage
It is recommended to use the `Makefile` located in the `Publication_Materials/` directory to run these scripts:
```bash
cd Publication_Materials
make reproduce
```
